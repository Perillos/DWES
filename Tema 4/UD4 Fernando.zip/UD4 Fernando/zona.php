<?php

include "dbcone.php";
include "head.php";

?>
<h3>Un usuario ya tiene ese DNI</h3>
<p>Introduce otro DNI.</p>
<div class='container'>
    <a href='registrate.php' class='button'>Nuevo</a>
</div>
<p>O ve al inicio.</p>
<div class='container'>
    <a href='index.php' class='button'>Volver</a>
</div>