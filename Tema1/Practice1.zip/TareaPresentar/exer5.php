

<?php
$name = "Juan";
$surname1 = "Valero";
$surname2 = "Ruiz";
$age = 23;
$adres = "C/ America, 33";
$postal = 34017;
$phone = 596209934;
$job = "Programador";




echo "<p>Nombre: <b>$name</b></p>";
echo "<p>Apellidos: <b>$surname1 $surname2</b></p>";
echo "<p>Edad: <b>$age</b></p>";
echo "<p>Domicilio: <b>$adres</b></p>";
echo "<p>Telefono: <b>$postal</b></p>";
echo "<p>Código Postal: <b>$phone</b></p>";
echo "<p>Profesión: <b>$job</b></p>";

?>