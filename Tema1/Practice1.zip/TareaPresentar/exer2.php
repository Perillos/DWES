<?php
echo "En un lugar de la mancha...";
/*
Comentario
en
bloque
*/
echo "<p>En un lugar de la mancha...</p>";
print("En un lugar de la mancha..."); // Comentario en linea

?>