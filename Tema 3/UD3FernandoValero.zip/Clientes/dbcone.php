<?php

$DB_URL="localhost";
$DB_USER="root";
$DB_PASS= "";
$DB_NAME="clientesdwes";

//Conectamos con MySQL y la base de datos club
$link = mysqli_connect($DB_URL, $DB_USER, $DB_PASS, $DB_NAME);

 

?>